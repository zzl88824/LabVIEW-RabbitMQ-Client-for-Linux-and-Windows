#include <amqp.h>
#include <amqp_tcp_socket.h>
#include <amqp_private.h>
#include <amqp_framing.h>
#include <string.h>
#include "utils.h"
#include "extcode.h"


//Windows��

//���ذ汾��
__declspec(dllexport)
char lv_rabbitmq_version() {
	char version = "0.0.1";
	return version;
}

//��������
int lv_die_on_amqp_error(amqp_rpc_reply_t x, char const *context) {
	switch (x.reply_type) {
	case AMQP_RESPONSE_NORMAL:
		return 1;

	case AMQP_RESPONSE_NONE:
		return 2;

	case AMQP_RESPONSE_LIBRARY_EXCEPTION:
		return 3;

	case AMQP_RESPONSE_SERVER_EXCEPTION:
		switch (x.reply.id) {
		case AMQP_CONNECTION_CLOSE_METHOD: {
			amqp_connection_close_t *m =
				(amqp_connection_close_t *)x.reply.decoded;
			return 4;
		}
		case AMQP_CHANNEL_CLOSE_METHOD: {
			amqp_channel_close_t *m = (amqp_channel_close_t *)x.reply.decoded;
			return 5;
		}
		default:
			return 6;
		}
		break;
	}

}


//��ȡmeassage.body����
int lv_amqp_dump(size_t len) {
	int count = 0;
	size_t i;

	for (i = 0; i < len; i++) {
		count++;
	}
	return count;
}



//����ȫ�ֱ���
amqp_bytes_t queuename;
struct lv_timeval {
	long    tv_sec;//��
	long	tv_usec;//΢��
};


//LabVIEW����ĵ�ַת��Ϊָ��
struct amqp_connection_state_t* lv_int_to_pointer(int *conn_int) {
	amqp_connection_state_t *x;
	x = (amqp_connection_state_t*)conn_int;
	return *x;
}


//����������
__declspec(dllexport)
void* lv_amqp_new_connction() {
	amqp_connection_state_t conn;
	conn = amqp_new_connection();
	return conn;
}

//�ر�����
__declspec(dllexport)
int lv_amqp_close_connection(int *conn_int) {
	amqp_connection_state_t *x;
	x = (amqp_connection_state_t*)conn_int;
	int r = lv_die_on_amqp_error(amqp_connection_close(*x, AMQP_REPLY_SUCCESS),"Connection close");
	return r;
}


//��������
__declspec(dllexport)
void lv_amqp_destroy_connection(int *conn_int) {
	amqp_connection_state_t *x;
	x = (amqp_connection_state_t*)conn_int;
	amqp_destroy_connection(*x);
}

// ��ͨ��
__declspec(dllexport)
void lv_amqp_channel_open(int *conn_int) {
	amqp_connection_state_t *x;
	x = (amqp_connection_state_t*)conn_int;
	amqp_channel_open(*x, 1);
}


// �ر�ͨ��
__declspec(dllexport)
int lv_amqp_channel_close(int *conn_int) {
	amqp_connection_state_t *x;
	x = (amqp_connection_state_t*)conn_int;
	int r = lv_die_on_amqp_error(amqp_channel_close(*x, 1, AMQP_REPLY_SUCCESS), "Closing channel");
	return r;
}

//�ж�״̬
__declspec(dllexport)
int lv_amqp_get_rpc_reply(int *conn_int, char *operation) {
	amqp_connection_state_t *x;
	x = (amqp_connection_state_t*)conn_int;
	lv_die_on_amqp_error(amqp_get_rpc_reply(*x), operation);
}

//����exchange
__declspec(dllexport)
void lv_amqp_exchange_declare(int *conn_int, char *exchange, char *exchangetype ) {
	amqp_connection_state_t *x;
	x = (amqp_connection_state_t*)conn_int;
	amqp_exchange_declare(*x, 1, amqp_cstring_bytes(exchange),
		amqp_cstring_bytes(exchangetype), 0, 0, 0, 0,
		amqp_empty_table);
}

//��½
__declspec(dllexport)
int lv_amqp_login(int *conn_int, char *host, int port, char *username, char *password) {

	amqp_connection_state_t *x;
	x = (amqp_connection_state_t*)conn_int;

	int status;
	amqp_socket_t *socket = NULL;
	socket = amqp_tcp_socket_new(*x);
	status = amqp_socket_open(socket, host, port);
	int r = lv_die_on_amqp_error(amqp_login(*x, "/", 0, 131072, 0, AMQP_SASL_METHOD_PLAIN,
		username, password),
		"Logging in");
	return r;

}

//������Ϣ
__declspec(dllexport)
void lv_amqp_basic_publish(int *conn_int, char *exchange, char *routingkey, char *messagebody) {
	amqp_connection_state_t *x;
	x = (amqp_connection_state_t*)conn_int;
	amqp_basic_properties_t props;
	props._flags = AMQP_BASIC_CONTENT_TYPE_FLAG | AMQP_BASIC_DELIVERY_MODE_FLAG;
	props.content_type = amqp_cstring_bytes("text/plain");
	props.delivery_mode = 2;
	die_on_error(amqp_basic_publish(*x, 1, amqp_cstring_bytes(exchange),
		amqp_cstring_bytes(routingkey), 0, 0,
		&props, amqp_cstring_bytes(messagebody)),
		"Publishing");
}







//������ϢSTEP1
__declspec(dllexport)
void lv_amqp_consume_message1(int *conn_int, char *exchange, char *bindingkey) {
	amqp_connection_state_t *x;
	x = (amqp_connection_state_t*)conn_int;
	amqp_queue_declare_ok_t *r = amqp_queue_declare(
		*x, 1, amqp_empty_bytes, 0, 0, 0, 1, amqp_empty_table);
	die_on_amqp_error(amqp_get_rpc_reply(*x), "Declaring queue");
	queuename = amqp_bytes_malloc_dup(r->queue);
	if (queuename.bytes == NULL) {
		//fprintf(stderr, "Out of memory while copying queue name");
		return "Out of memory while copying queue name";
	}


	amqp_queue_bind(*x, 1, queuename, amqp_cstring_bytes(exchange),
		amqp_cstring_bytes(bindingkey), amqp_empty_table);
	die_on_amqp_error(amqp_get_rpc_reply(*x), "Binding queue");

	amqp_basic_consume(*x, 1, queuename, amqp_empty_bytes, 0, 1, 0,
		amqp_empty_table);
	die_on_amqp_error(amqp_get_rpc_reply(*x), "Consuming");

}


//������ϢSTEP2
__declspec(dllexport)
char *lv_amqp_consume_message2(int *conn_int, int *e, int *number) {
	char  *aaa;
	amqp_connection_state_t *x;
	x = (amqp_connection_state_t*)conn_int;
	//���û�ȡ���ݵĳ�ʱʱ��
	struct lv_timeval lv_timeval1;
	lv_timeval1.tv_sec = 0;
	lv_timeval1.tv_usec = 100000;

		amqp_rpc_reply_t res;
		amqp_envelope_t envelope;
		amqp_maybe_release_buffers(*x);
		res = amqp_consume_message(*x, &envelope, &lv_timeval1, 0);

		if (envelope.message.body.len > 0) {
			*number = lv_amqp_dump(envelope.message.body.len);
			*e = &envelope;
			//amqp_destroy_envelope(&envelope);
			aaa = envelope.message.body.bytes;

			//return envelope.message.body.bytes;
			return aaa;
		}
		else {
			return "null";
		}

		
		//amqp_destroy_envelope(&envelope);
		
}


//����envelop
__declspec(dllexport)
void lv_amqp_destroy_envelope(int *envelope) {
	amqp_envelope_t *x;
	x = (amqp_envelope_t*)envelope;
	//amqp_destroy_envelope(envelope);
	amqp_destroy_envelope(x);

}



/* Handle "cnt" field is int32 so max length is INT32_MAX. */
#define MaxHandleStringLength INT32_MAX

_declspec(dllexport) void LVLStrHandle(int *conn_int, int *number, LStrHandle input, LStrHandle output);
_declspec(dllexport) void LVLStrHandle(int *conn_int, int *number, LStrHandle input, LStrHandle output)
{
	int32 len;
	uInt32 i, j, stringLength;
	uInt32 temp;
	temp = 50;


	char  *aaa;
	amqp_connection_state_t *x;
	x = (amqp_connection_state_t*)conn_int;
	//���û�ȡ���ݵĳ�ʱʱ��
	struct lv_timeval lv_timeval1;
	lv_timeval1.tv_sec = 0;
	lv_timeval1.tv_usec = 100000;

	amqp_rpc_reply_t res;
	amqp_envelope_t envelope;
	amqp_maybe_release_buffers(*x);
	res = amqp_consume_message(*x, &envelope, &lv_timeval1, 0);

	if (envelope.message.body.len > 0) {
		*number = lv_amqp_dump(envelope.message.body.len);

		//amqp_destroy_envelope(&envelope);
		aaa = envelope.message.body.bytes;

		//return envelope.message.body.bytes;






		len = (*input)->cnt;
		/* If we really have a handle, make sure it has enough room.. */
		if (!DSCheckHandle(output)) {
			stringLength = len * 2;
			if (stringLength > MaxHandleStringLength) {
				stringLength = MaxHandleStringLength;
			}

			if ((*output)->cnt < stringLength) {
				/* Adjust the handle size to hold everything we want to put in it */
				DSSetHandleSize((void*)output, stringLength);
			}

			if (!DSCheckHandle(output)) {
				strncpy((*output)->str, (*input)->str, len);
				/* Reverse "i" characters. */
				/*
				for ( i = len, j = 0; ( i > 0 ) && ( j < ( stringLength - len )); j++ )
				{
				(*output)->str[j + len] = (*input)->str[--i];
				}
				*/
				char *bbb;
				bbb = envelope.message.body.bytes;
				int l = strlen(bbb);
				if (l > 0) {
					for (i = 0; i < l; i++) {
						(*output)->str[i] = bbb[i];
					}
				}
				(*output)->cnt = l;
			}
		}



	}
	else {

	}
	
	
	amqp_destroy_envelope(&envelope);


}




/*
//---------------------�Դ�ָ�뷽ʽ����-------------------------//

//����������
__declspec(dllexport)
void* lv2_amqp_new_connction() {
	//volatile amqp_connection_state_t conn;
	amqp_connection_state_t conn;
	conn = amqp_new_connection();
	return conn;
}

//��������
__declspec(dllexport)
void lv2_amqp_destroy_connection(int *conn2) {
	amqp_connection_state_t *x;
	x = (amqp_connection_state_t*)conn2;
	amqp_destroy_connection(*x);
}
*/